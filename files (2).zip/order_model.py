class Order:
    def __init__(self, student, restaurant):
        self.student = student
        self.restaurant = restaurant
        self.items = []  # list of (item, quantity) tuples

    def add_item(self, item, quantity):
        self.items.append((item, quantity))

    def calculate_total(self):
        # get the raw total using recursion
        raw_total = self._sum_items(self.items)

        # apply a simple discount rule at the end
        # placeholder rule: 10% off if total is more than GHS 100
        if raw_total > 100:
            return raw_total * 0.9
        else:
            return raw_total

    def _sum_items(self, items):
        # base case: no items left, nothing to add
        if len(items) == 0:
            return 0

        # take the first item off the list
        item, quantity = items[0]
        line_total = item.get_price() * quantity

        # recurse on everything else
        rest_total = self._sum_items(items[1:])

        return line_total + rest_total
